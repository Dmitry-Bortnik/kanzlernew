<?php
require_once('head.php');
?>
<?php
require_once('footer.php');
require_once('foot.php'); ?>

