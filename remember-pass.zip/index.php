<?php require_once('head.php');?>

<div class="link-list"
     style="
     max-width: 700px;
     margin: 0 auto;
      width: 100%;
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      padding: 20px; font-weight: bold;">
  <a href="page_gid_style.php">Гид по стилю</a>
  <a href="page_post.php">Страница статьи</a>
  <a href="page_archive.php">Страница Архив статей</a>
  <a href="page_card.php">Страница Карт</a>
  <a href="page_payment_error.html">Страница ошибки оплаты</a>
  <a href="page_payment_success.html">Страница успешной оплаты</a>
  <a href="footer-test.php">Тест футера</a>
  <a href="modal_reservation-test.php">Тест открытия модального окна бронирования</a>
  <a href="checkout.php">Чекаут</a>
  <a href="auth.php">Авторизация</a>
  <a href="remember-pass.php">Вспомнить пароль</a>
    <br>
  <a href="mail_new_order.html">1-(Новый-полученный-заказ)</a>
  <a href="mail_order_confirmed.html">2-(Ваш-заказ-подтвержден-и-передан-в-комплектацию)</a>
  <a href="mail_order_to_delivery.html">3-(Ваш-заказ-передан-на-доставку-в-курьерскую-службу)</a>
  <a href="mail_order_delivered.html">4-(Ваш-заказ-доставлен-в-пункт-самовывоза)</a>
  <a href="mail_order_success.html">5-(Заказ-выполнен)</a>
    <br>
    <a href="modal_pickuppoints-test.php">Тест открытия модального окна П.Самовывоза</a>

</div>


