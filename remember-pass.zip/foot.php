
<script
        src="https://code.jquery.com/jquery-3.5.1.js"
        integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc="
        crossorigin="anonymous"></script>
<script src="https://api-maps.yandex.ru/2.1/?lang=ru_RU&apikey=e3cc03a6-f4cf-4fe8-ad47-eedc86ebd525" type="text/javascript"></script>
<script src="js/map_yandex.js"></script>
<script src="js/map.js"></script>
<!--<script src="js/script.js"></script>-->
<script src="https://kanzler-style.ru/bitrix/templates/kanzler-template/js/maskinput.js"></script>
<script src="js/custom.js"></script>
</body>
</html>
