<!doctype html>
<html lang="ru">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Document</title>

  <!-- текущие необходимые стили на сайте, не стоит использовать повторно -->
  <link rel="stylesheet" href="css/fonts.css">
  <link rel="stylesheet" href="css/foundation.css">
  <link rel="stylesheet" href="css/str.css">
  <link rel="stylesheet" href="css/style.css">
  <!-- текущие необходимые стили на сайте, не стоит использовать повторно -->

  <!-- нужные стили для новых сверстанных страниц -->
  <link rel="stylesheet" href="css/dr-custom.css">
  <!-- нужные стили для новых сверстанных страниц -->

  <link rel="stylesheet" href="css/checkout/checkout-data.css">
  <link rel="stylesheet" href="css/checkout/checkout-products.css"> 
  <link rel="stylesheet" href="css/checkout/checkout-sidebar.css">
  <link rel="stylesheet" href="css/checkout/mobile-fixed.css">
  <link rel="stylesheet" href="css/auth.css">
</head>
<body>

