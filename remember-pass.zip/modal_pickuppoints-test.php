<?php

require_once('head.php');
?>

    <a href="#" class="dr-btn dr-btn__outline" data-modal="modal-pickuppoint">
        Открыть модальное окно
    </a>

<?php

require_once("modal_pickuppoints.php");
require_once('foot.php');
