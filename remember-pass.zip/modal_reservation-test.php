<?php

require_once('head.php');
?>

    <a href="#" class="dr-btn dr-btn__outline" data-modal="modal-reservation">
        Открыть модальное окно бронирования
    </a>

<?php

require_once("modal_reservation.php");
require_once("modal_contact_details.php");
require_once('foot.php');
